// funUsu.js 
"use strict";

function validaFormulUsu() {
}

function compruebaContra(pass, lonMin, minNum, minMayus, minMinus, nomUsu) {
}

function inicial() {
}

window.onload = inicial;
