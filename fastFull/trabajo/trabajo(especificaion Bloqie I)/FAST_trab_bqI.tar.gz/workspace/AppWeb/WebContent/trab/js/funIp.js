// funIp.js
"use strict";

function procesaIp(cadena) {
}

function ipToBin(cadena) {
}

function validaFormulIp() {
}


function creaFila(ip) {
}

function mostrarRedes(redes) {
}

function pedirRedesURL() {
}

function inicial() {
}

window.onload = inicial;

