package fast1718.trabajo;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 * Servlet implementation class ServletNuevaInterfaz
 */
// TODO MODIFICAR
//@WebServlet("")
public class ServletNuevaInterfaz extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletNuevaInterfaz() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		boolean error = false;
		try {
			Usuario usuario = (Usuario) request.getSession().getAttribute("usuario");
			DataSource ds = (DataSource) request.getServletContext().getAttribute("ds");
			Connection conn = ds.getConnection();
			String tipo = request.getParameter("tipo");
			String interfaz = request.getParameter("interfaz");
			String equipo = request.getParameter("equipo");
			// Comprobar parámetros
			if (tipo == null || equipo == null || interfaz == null 
					|| tipo.isEmpty() || equipo.isEmpty() || interfaz.isEmpty()) {
				// Error comprobación datos
				error = true;
			} else {
				boolean usuCorrecto = false;
				//Obtener si el equipo es del usuario o es administrador
				if (usuario.getTipo_usu()==Usuario.ADMINISTRADOR) {
					usuCorrecto = true;
				} else {
					String sql = "SELECT id_usuario FROM equipos "
							+ "WHERE id_usuario=? AND id_eq=?";
					PreparedStatement pst = conn.prepareStatement(sql);
					pst.setString(1, usuario.getUsu());
					pst.setString(2, equipo);
					ResultSet rs = pst.executeQuery();
					if (rs.next()) {
						usuCorrecto = true;
					}
					rs.close();
					pst.close();
				}
				if (usuCorrecto) {
					// Realizar la operación
					String sql = "INSERT INTO interfaces VALUES (?,?,?)";
					PreparedStatement st = conn.prepareStatement(sql);
					st.setString(1, equipo);
					st.setInt(2, Integer.parseInt(interfaz));
					st.setInt(3, Integer.parseInt(tipo));
					int rows = st.executeUpdate();
					if (rows == 1) {
						//Correcto.
					} else {
						error = true;
						//Error
					}
					st.close();
					conn.close();
				} else {
					error = true;
				}
			}
		} catch (Exception e) {
			//Error
			e.printStackTrace();
			error = true;
		}
		
		if (error) {
			// TODO MODIFICAR
			//request.setAttribute("", "Error creando la nueva interfaz.");
			//request.setAttribute("volverURL", "");
			//request.getRequestDispatcher("").forward(request, response);
		} else {
			// TODO COMPLETAR

		}
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
