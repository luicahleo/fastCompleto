"use strict";

window.addEventListener("load", function(){iniciaTablas(rellenaTabla)});
