"use strict";

window.addEventListener("load", function(){iniciaTablas(function(ident, elementos) {
	rellenaTabla(ident, elementos);
	modificaTabla(ident, 3, 2, "asigna IP", "ipForm.jsp");
})});

