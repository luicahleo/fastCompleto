function muestraFormAcceso() {
	// COMPLETAR


}

function ocultaFormAcceso() {
	// COMPLETAR



}

window.addEventListener("load", function() {
	// COMPLETAR



});
