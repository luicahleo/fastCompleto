<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
 <title> Noticias.php </title>
</head>
<body>
<div id="personal">
<ul>
  <li> personal 1 </li> <li> personal 2 </li>
  <li> personal 3 </li><li> personal 4 </li>
</ul>
</div>

<div id="novedades">
Novedades a las <?php echo date("d-m-Y H:i:s"); ?>
<ul>
<li> Novedad 1 </li><li> Novedad 2 </li>
<li> Novedad 3 </li><li> Novedad 4 </li>
</ul>
</div>

</body>
</html>