var datos_aut=[
["AND","ANDALUCIA"],
["EXT","EXTREMADURA"]
];


var datos_prov_loc_AND =[
[["JA","JAEN"],["CO","CORDOBA"],["SE","SEVILLA"],["HU","HUELVA"],["CA","CADIZ"],["MA","MALAGA"],["GR","GRANADA"],["AL","ALMERIA"]],
["SE",[["BOR","BORMUJOS"],["GIN","GINES"],["SJA", "SAN JUAN DE AZNALFARACHE"],["SEV","SEVILLA"],["TOM","TOMARES"]]],
["HU",[["LEP","LEPE"],["HUE","HUELVA"]]],
["JA",[["BAE","BAEZA"],["JAE","JAEN"]]],
["CO",[["PRI","PRIEGO DE CORDOBA"],["COR","CORDOBA"]]],
["CA",[["JER","JEREZ DE LA FRONTERA"],["CAD","CADIZ"]]],
["MA",[["MAL","MALAGA"],["MAR","MARBELLA"]]],
["GR",[["GRA","GRANADA"],["GUA","GUADIX"]]],
["AL",[["ALM","ALMERIA"],["CAR","CARBONERAS"],["ADR","ADRA"]]]
];

var datos_prov_loc_EXT =[
[["CC","CACERES"],["BA","BADAJOZ"]],
["CC",[["CAC","CACERES"],["TRU","TRUJILLO"]]],
["BA",[["BAD","BADAJOZ"],["MER","MERIDA"]]],
];

var datos_provloc;				// contiene la tabla de prov y loc asociada a la com. aut. seleccionada

function rellena_sel(identif_de_select,datos) {
	var nodoSelect=document.getElementById(identif_de_select);
	var tam=datos.length;
	for (var i=0; i<tam; i++){                               // para cada elemento de datos
		var nodoOpcion=document.createElement("OPTION");     // crea un elemento con etiqueta option
		nodoOpcion.setAttribute("value", datos[i][0]);       // le añade el atributo value con el valor de datos[i][0]
		var nodoTexto=document.createTextNode(datos[i][1]);  // crea un nodo de texto con el valor de datos[i][1]
		nodoOpcion.appendChild(nodoTexto);                   // añade el nodo de texto al nodo elemento option
		nodoSelect.appendChild(nodoOpcion);                  // añade el nodo elemento option al nodo elemento select
	}
	return nodoSelect;
}

function obtiene_pl(op){
	var result;
	switch (op) {
    case "AND":
        result = datos_prov_loc_AND;
        break;
    case "EXT":
        result = datos_prov_loc_EXT;
        break;
	}
	return result;
}

function obtiene_loc(op, datos_pl){
	var result=null;
	var i=1;
	var tam=datos_pl.length;
	while (i<tam && result==null){
		if (datos_pl[i][0]==op)
			result=datos_pl[i][1];
		i++;
	}
	return(result);
}

function borra_sel(identif_de_select) {
	var nodoSelect=document.getElementById(identif_de_select);
	while(nodoSelect.children.length>1)
		nodoSelect.removeChild(nodoSelect.children[1]);
}

function ha_cambiado(nodo){
	var op=nodo.value;
	borra_sel("sel_loc");									// tanto si cambia la prov. como la com. aut., hay que borrar las localidades
	switch(nodo.id){
	case "sel_aut":
		borra_sel("sel_prov");
		datos_provloc=obtiene_pl(op);						// datos_provloc es global, se usa para llamar a obtiene_loc cuando cambie la prov
		rellena_sel("sel_prov", datos_provloc[0]);
		break;
	case "sel_prov":
		var datos_loc=obtiene_loc(op, datos_provloc);
		rellena_sel("sel_loc", datos_loc)
		break;
	}
}

function rellena_aut(){
	var nodoSelAut=rellena_sel("sel_aut", datos_aut);
	nodoSelAut.onchange=function(){ha_cambiado(nodoSelAut)};
	var nodoSelProv=document.getElementById("sel_prov");
	nodoSelProv.onchange=function(){ha_cambiado(nodoSelProv)};
}

document.body.onload=function(){rellena_aut()};


