javac -cp /usr/share/java/servlet-api-3.1.jar \
	-d build/classes \
	src/ej_jbean/*.java \
	src/fast/*.java \
	src/fast/anotaciones/*.java

