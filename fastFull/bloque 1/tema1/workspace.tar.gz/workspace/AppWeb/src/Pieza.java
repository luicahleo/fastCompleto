/**
 * 
 */


import java.io.Serializable;

/**
 * @author dit
 *
 */
public class Pieza implements Serializable {

}
